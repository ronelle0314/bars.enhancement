package com.accenture.bars.domain;

public class LoginSession {

	private static LoginSession instance;
	private Record account;

	private LoginSession() {

	}

	public static LoginSession getInstance() {
		if(instance == null) {
			instance = new LoginSession();
		}

		return instance;
	}

	public void setAccount(Record newAccount) {
		account = newAccount;
	}

	public Record getCurrentAccount() {
		return account;
	}
	
}
