package com.accenture.bars.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.accenture.bars.domain.Billing;

public interface BillingRepository extends JpaRepository<Billing, Integer> {

	Billing findByBillingId(int billingId);

}
