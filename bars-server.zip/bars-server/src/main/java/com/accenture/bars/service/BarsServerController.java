package com.accenture.bars.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.accenture.bars.repository.AccountRepository;
import com.accenture.bars.repository.BillingRepository;
import com.accenture.bars.repository.CustomerRepository;
import com.accenture.bars.repository.RequestRepository;

@Controller
public class BarsServerController {
	protected static final Logger logger = LoggerFactory.getLogger(BarsServerController.class);
	@Autowired
	RequestRepository requestRepository;
	
	@Autowired
	BillingRepository billingRepository;
	
	@Autowired
	CustomerRepository customerRepository;
	
	@Autowired
	AccountRepository accountRepository;

	@RequestMapping(value = "/deleteCustomer")
	public String roleFromAccount(@RequestParam(value = "customerId", required = true) String customerId){
		int custId = Integer.parseInt(customerId);
		
		customerRepository.delete(custId);
		
		return "redirect:http://localhost:2019/showCustomer";
	}
	
	@RequestMapping(value = "/hello")
	public String roleFromt(){
		
		
		return "hello";
	}
}
